//
//  GeoSpark.h
//  GeoSpark
//
//  Created by GeoSpark Mac 15 on 24/09/20.
//  Copyright © 2020 GeoSpark Mac 15. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GeoSpark.
FOUNDATION_EXPORT double GeoSparkVersionNumber;

//! Project version string for GeoSpark.
FOUNDATION_EXPORT const unsigned char GeoSparkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GeoSpark/PublicHeader.h>


